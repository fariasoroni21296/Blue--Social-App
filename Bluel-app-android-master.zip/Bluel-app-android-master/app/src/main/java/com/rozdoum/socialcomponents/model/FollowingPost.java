package com.rozdoum.socialcomponents.model;

/**
 * Created by Alexey on 22.05.18.
 */
public class FollowingPost {

    private String postId;

    public FollowingPost() {
    }

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

}
